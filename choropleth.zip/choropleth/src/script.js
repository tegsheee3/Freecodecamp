let width=1200
let height=700
let padding=60
let baseTemp
let xAxis
let yAxis
let xScale
let yScale
let svg=d3.select("svg")
let tooltip=d3.select("#tooltip")
let eduUrl="https://cdn.freecodecamp.org/testable-projects-fcc/data/choropleth_map/for_user_education.json"
let countyUrl="https://cdn.freecodecamp.org/testable-projects-fcc/data/choropleth_map/counties.json"
let eduData
let countyData
d3.json(countyUrl).then(
(data,error)=>{
  if(error){console.log(error)}else{countyData=topojson.feature(data,data.objects.counties).features; console.log(countyData)
                                 d3.json(eduUrl).then(
                                 (data,error)=>{
                                 if(error){console.log(error)}else{eduData=data;
                                                                   canvasGen(),
                                                                     mapGen()
                                                                  }})
                                 }
}
)

let canvasGen=()=>{
  svg.attr("width",width)
  .attr("height",height)
  d3.select("#legend")
  .attr("width",width)
  .attr("height",170)
}
let mapGen=()=>{
  svg.selectAll("path")
  .data(countyData)
  .enter()
  .append("path")
  .attr("d",d3.geoPath())
  .attr("class","county")
  .attr("fill",(countyItem)=>{
    let id=countyItem["id"]
    let county=eduData.find((item)=>{
      return item["fips"]===id
    })
    let perc=county["bachelorsOrHigher"]
    if(perc<=20){return "red"}
    else if(perc<=40){return"orange"}
    else if(perc<=50){return "green"}
    else return "blue"
  })
  .attr("data-fips",(item)=>{
    return item["id"]
  })
  .attr("data-education",(countyItem)=>{
    let id=countyItem["id"]
    let county=eduData.find((item)=>{
      return item["fips"]===id
    })
    let perc=county["bachelorsOrHigher"]
    return perc
  })
  .on("mouseover",(e,countyitem)=>{
    tooltip.transition()
    .style("visibility","visible")
    let id=countyitem["id"]
    let county=eduData.find((item)=>{
      return item["fips"]===id})
    tooltip.text(county["fips"]+"-"+county["area_name"]+","+county["state"]+":"+county["bachelorsOrHigher"]+"%")
    .attr("data-education",county["bachelorsOrHigher"])
  })
  .on("mouseout",(e,item)=>{
    tooltip.transition()
    .style("visibility","hidden")
  })
}