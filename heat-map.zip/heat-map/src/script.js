let width=1200
let height=900
let padding=60
let values=[]
let baseTemp
let xAxis
let yAxis
let xScale
let yScale
let svg=d3.select("svg")
let tooltip=d3.select("#tooltip")
let monthNames = ["January", "February", "March","April", "May", "June","July", "August", "September", "October", "November", "December"]
let url="https://raw.githubusercontent.com/freeCodeCamp/ProjectReferenceData/master/global-temperature.json"
const req=new XMLHttpRequest()
req.open("GET",url,true)
req.send()
req.onload=()=>{
  let object=JSON.parse(req.responseText)
  baseTemp=object["baseTemperature"]
  values=object["monthlyVariance"]
  canvasGen()
  scaleGen()
  axesGen()
  cellGen()
}

let canvasGen=()=>{
  svg.attr("width",width)
  .attr("height",height)
  d3.select("#legend")
  .attr("width",width)
  .attr("height",height)
}
let scaleGen=()=>{
  xScale=d3.scaleLinear()
  .range([padding,width-padding])
  .domain([d3.min(values,(item)=>{return item["year"]}),
           d3.max(values,(item)=>{ return item["year"]+1})])
  yScale=d3.scaleTime()
  .range([padding,height-padding])
  .domain([new Date(0,0,0,0, 0, 0, 0), new Date(0,12,0,0,0,0,0)])
} 
let axesGen=()=>{
  xAxis=d3.axisBottom(xScale)
  .tickFormat(d3.format("d"))
  svg.append("g")
  .call(xAxis)
  .attr("id","x-axis")
  .attr("transform","translate(0,"+(height-padding)+")")
  yAxis=d3.axisLeft(yScale)
  .tickFormat(d3.timeFormat("%B"))
  svg.append("g")
  .call(yAxis)
  .attr("id","y-axis")
  .attr("transform","translate("+padding+",0)")
}
let cellGen=()=>{
  svg.selectAll("rect")
  .data(values)
  .enter()
  .append("rect")
  .attr("class","cell")
  .attr("fill",(item)=>{
            if(item['variance'] <= -1){
                return 'blue'
            }else if(item['variance'] <= 0){
                return 'green'
            }else if(item['variance'] <= 1){
                return 'Orange'
            }else{
                return 'Crimson'
            }
   //  variance=item["variance"]
   // variance<=-1?"blue":variance<=0?"green":variance<=1?"Orange":"red"
  })
  .attr("data-year",(item)=>{
        return item["year"]
        })
   .attr("data-month",(item)=>{
        return item["month"]-1
        })
   .attr("data-temp",(item)=>{
        return baseTemp+item["variance"]
        })
  .attr("height",(height-padding*2)/12)
  .attr("y",(item)=>{
    return yScale(new Date(0,item["month"]-1))
  })
  .attr("x",(item)=>{
    return xScale(new Date(item["year"]))
  })
  .attr("width",(width-padding*2)/(d3.max(values,(item)=>{return item["year"]})-
           d3.min(values,(item)=>{ return item["year"]})))
  .on('mouseover', (e,item) => {
            tooltip.transition()
                .style('visibility', 'visible')
    tooltip.text(item['year'] + ' ' + monthNames[item['month'] -1 ] + ' : ' + item['variance'])

    tooltip.attr('data-year', item['year'])
  })
    .on('mouseout', (e,item) => {
    tooltip.transition()
      .style('visibility', 'hidden')
  })
}