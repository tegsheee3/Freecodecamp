let width=900
let height=900
let padding=40
let dataset=[]
let xAxis
let yAxis
let xScale
let yScale
let svg=d3.select("svg")
const req=new XMLHttpRequest()
req.open("GET","https://raw.githubusercontent.com/freeCodeCamp/ProjectReferenceData/master/cyclist-data.json",true)
req.send()
req.onload=()=>{
  dataset=JSON.parse(req.responseText)
  canvasGen()
  scaleGen()
  axesGen()
  dots()
}

let canvasGen=()=>{
  svg.attr("width",width)
  .attr("height",height)
}

let scaleGen=()=>{
  xScale=d3.scaleLinear()
  .range([padding,width-padding])
  .domain([d3.min(dataset,(d)=>{
    return d["Year"]
  })-1,d3.max(dataset,(d)=>{
    return d["Year"]
  })+1]);
  yScale=d3.scaleTime()
  .range([padding,height-padding])
  .domain([d3.min(dataset,(d)=>{
    return new Date(d["Seconds"]*1000)
  }),d3.max(dataset,(d)=>{
    return new Date(d["Seconds"]*1000)
  })]);
}

let axesGen=()=>{
  xAxis=d3.axisBottom(xScale)
  .tickFormat(d3.format("d"))
  svg.append("g")
  .call(xAxis)
  .attr("id","x-axis")
  .attr("transform","translate(0,"+(height-padding)+")")
  
  yAxis=d3.axisLeft(yScale)
    .tickFormat(d3.timeFormat("%M:%S"))

  svg.append("g")
  .call(yAxis)
  .attr("id","y-axis")
  .attr("transform","translate("+(padding)+",0)")
}
let dots=()=>{
  svg.selectAll("circle")
  .data(dataset)
  .enter()
  .append("circle")
  .attr("class","dot")
  .attr("r","5")
  .attr("data-xvalue",(item)=>{
    return item["Year"]
  })
  .attr("data-yvalue",(item)=>{
    return new Date(item["Seconds"]*1000)
  })
  .attr("cx",(item)=>{
    return xScale(item["Year"])
  })
  .attr("cy",(item)=>{
    return yScale(new Date(item["Seconds"]*1000))
  })
  .attr("fill",(item)=>{
    if(item["Doping"]!=""){
      return "red"
    }else {return "green"}
  })
  .on("mouseover",(e,item)=>{
    tooltip.transition()
    .style("visibility","visible")
    if(item["Doping"]!=""){
      tooltip.text(item["Year"]+"-"+item["Name"]+"-"+item["Time"]+"-"+item["Doping"])
    }else {
      tooltip.text(item["Year"]+"-"+item["Name"]+"-"+item["Time"])
     }
    tooltip.attr('data-year', item['Year'])
  })
  .on("mouseout",(e,item)=>{
    tooltip.transition()
    .style("visibility","hidden")
  })
  
}
let tooltip=d3.select("#tooltip")


