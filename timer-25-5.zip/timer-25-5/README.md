# timer 25+5

A Pen created on CodePen.io. Original URL: [https://codepen.io/tegsheee3/pen/GRdYgNN](https://codepen.io/tegsheee3/pen/GRdYgNN).

