let gameurl="https://cdn.freecodecamp.org/testable-projects-fcc/data/tree_map/kickstarter-funding-data.json"
let movieurl="https://cdn.freecodecamp.org/testable-projects-fcc/data/tree_map/movie-data.json"
let pledgeurl="https://cdn.freecodecamp.org/testable-projects-fcc/data/tree_map/kickstarter-funding-data.json"
let moviedata
let svg=d3.select("#canvas")
let tooltip=d3.select("#tooltip")
let draw=()=>{
  

    let hierarchy = d3.hierarchy(moviedata, (node) => {
        return node['children']
    }).sum((node) => {
        return node['value']
    }).sort((node1, node2) => {
        return node2['value'] - node1['value']
    })

    let createTreeMap = d3.treemap()
                            .size([900, 900])
    
    createTreeMap(hierarchy)

    let movieTiles = hierarchy.leaves()
    console.log(movieTiles)

    let block = svg.selectAll('g')
            .data(movieTiles)
            .enter()
            .append('g')
            .attr('transform', (movie) => {
                return 'translate(' + movie['x0'] + ', ' + movie['y0'] + ')'
            })
    .on("mouseover",(e,item)=>{
      let revenue=item["data"]["value"].toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")
    tooltip.transition()
    .style("visibility","visible")
      .text("$"+revenue)
    .attr("data-value",item["data"]["value"])
  })
  .on("mouseout",(e,item)=>{
    
    tooltip.transition()
    .style("visibility","hidden")
    
  })

    block.append('rect')
            .attr('class', 'tile')
  .attr("fill",(movie)=>{
      let category=movie["data"]["category"]
      switch(category){
        case "Action":return"red";break;
          case "Drama":return"orange";break;
          case "Adventure":return"yellow";break;
          case "Family":return"green";break;
          case "Animation":return"blue";break;
          case "Comedy":return"violet";break;
          case "Biography":return"indigo";break;}
    })
  .attr("data-name",(movie)=>{
      return movie["data"]["name"]
    })
  .attr("data-category",(movie)=>{
      return movie["data"]["category"]
    })
  .attr("data-value",(movie)=>{
      return movie["data"]["value"]
    })
  .attr("width",(movie)=>{
      return movie["x1"]-movie["x0"]
    })
  .attr("height",(movie)=>{
      return movie["y1"]-movie["y0"]
    })
  
  block.append("text")
  .text((movie)=>{
    return movie["data"]["name"]
  })
  .attr("x",5)
  .attr("y",20)
  
}

d3.json(movieurl).then(
(data,error)=>{
  if(error){console.log(error)}else{moviedata=data 
                                    draw()}
})